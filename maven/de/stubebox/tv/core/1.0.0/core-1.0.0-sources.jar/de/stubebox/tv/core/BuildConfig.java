/**
 * Automatically generated file. DO NOT MODIFY
 */
package de.stubebox.tv.core;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "de.stubebox.tv.core";
  public static final String BUILD_TYPE = "release";
  // Field from default config.
  public static final String CORE_VERSION = "1.0.0";
}
