package de.stubebox.tv.player

import java.util.concurrent.ConcurrentHashMap
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * Per-provider live-stream quirks learned at runtime, shared by both engines.
 *
 * Keyed by `host:port` so a lesson learned on one channel applies immediately to every other channel of
 * the same panel (these faults are panel-wide, not per-channel). The panel-wide lessons listed in
 * [ProviderLessons] are also **kept across app starts for up to a week** ([startPersisting]), so the first
 * tune after a restart goes straight to the path that works instead of paying for the failure again.
 * Everything else here is in-memory for the session only.
 *
 * Three quirks are tracked:
 *
 *  1. **`.ts` that is really HLS.** Some Xtream panels advertise `/live/user/pass/ID.ts` but
 *     HTTP-redirect it to an `.m3u8` manifest. ExoPlayer picks its media source from the URL
 *     *before* that redirect and hands a text manifest to the progressive extractor
 *     (`ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED`); mpv/FFmpeg treats the manifest response's EOF as
 *     a broken raw stream and reconnects to the same 1.8 KB body forever (permanent black screen).
 *     Once either engine has seen the redirect land on a manifest we remember it here.
 *
 *  2. **Per-segment signed URLs that Media3 cannot keep fresh.** The panel this was traced on hands
 *     out segment URLs carrying a short-lived signed token
 *     (`/serve/<id>/<token>/<token>/…/136875_2559.ts`) and answers **every** one of them with
 *     `403 "Invalid token 2"` — the playlist itself keeps returning 200, and not a single segment ever
 *     succeeds. Media3's chunk pipeline can only re-issue the *identical* URL it resolved from the
 *     playlist snapshot, so once a token has aged out the channel can never recover; FFmpeg (mpv, VLC)
 *     re-reads the playlist and fetches with a fresh token, which is why the same channel plays there,
 *     lagging but alive. There is nothing to tune — the fix is to recognise the pattern quickly and
 *     hand the panel to mpv, rather than grinding ExoPlayer's reconnect ladder on a dead channel.
 *
 *  3. **A panel that blocklists the default User-Agent.** Some hosts sit behind a WAF that refuses
 *     player identities by name. Traced on a Cloudflare-fronted panel that answers every request
 *     carrying `VLC/3.0.20 LibVLC/3.0.20` with a `403` challenge page ("Just a moment…") and serves the
 *     identical URL `200` to a neutral UA. Both engines send the VLC identity, so such a channel fails
 *     on ExoPlayer, walks the whole fallback ladder, and fails on mpv too — indistinguishable from a
 *     dead provider. Once either engine has been refused this way we remember it here, so every other
 *     channel on the panel opens under [de.stubebox.tv.core.network.HttpClient.FALLBACK_USER_AGENT]
 *     first time instead of repeating the failure.
 */
object LiveStreamQuirks {

    /**
     * How many distinct live segments a provider must refuse before we stop trying on ExoPlayer.
     *
     * Two, not one: a single 403 can be a genuine one-off (a segment rolled out of the window mid-flight),
     * and the load-error policy already absorbs that with one quick retry. Two *different* segments
     * refused in the same load is the signature of a URL-signing scheme Media3 structurally cannot
     * satisfy, and every further attempt just costs the user another dead spinner.
     */
    const val REFUSALS_BEFORE_HANDOFF = 2

    /** HTTP statuses a panel uses to refuse a segment outright. Never worth hammering the same URL for. */
    fun isEdgeRefusal(responseCode: Int): Boolean =
        responseCode == 403 || responseCode == 404 || responseCode == 410

    /**
     * The non-standard status a panel returns when the account's one allowed session is already in use.
     *
     * Traced on a panel whose edge answers `458` with an empty `text/html` body and no redirect, while a
     * permitted request is redirected through to the origin. It is not an HTTP standard code — Xtream
     * panels invent codes in this range for "max connections" — so it is matched exactly rather than by
     * class, and it means something very different from [isEdgeRefusal]: the stream is fine, *we* are the
     * second client.
     *
     * `407` joins it for the same reason. A panel fronted by a gateway answers the *reconnect* with
     * "Proxy Authentication Required" while the dying connection is still counted against the
     * account, even though no proxy is in play — traced on a television whose channel had played for
     * twenty seconds with zero dropped frames, then burned all eight reconnects on `407` in six
     * seconds and gave up. The stream was never the problem: the previous socket had not finished
     * closing. Waiting once is the answer here exactly as it is for `458`.
     *
     * `460` is the same answer from another panel family: an empty `text/html` body from a Cloudflare
     * front, measured for about a minute after a phone lost its network mid-play, until the panel let go
     * of the connection the outage had killed.
     */
    fun isSessionLimit(responseCode: Int): Boolean =
        responseCode == 458 || responseCode == 460 || responseCode == PlayerErrors.HTTP_PROXY_AUTH

    /**
     * Statuses a WAF uses to refuse a request on *who is asking* rather than what was asked for — worth
     * one retry under a different identity before the stream is written off.
     *
     * `403` is the Cloudflare managed-challenge answer traced on the panel in the quirk-3 note above;
     * `503` is the same product's "checking your browser" variant. Only ever consulted **before the
     * first frame** (see the caller): once a channel has played, a mid-stream `403` is a stale segment
     * token, which is [isEdgeRefusal]'s business and a new UA cannot help it.
     */
    fun isIdentityRefusal(responseCode: Int): Boolean = responseCode == 403 || responseCode == 503

    /** `host:port` of [url], lowercased; the whole URL when it can't be parsed (still a stable key). */
    fun hostKey(url: String): String {
        val afterScheme = url.substringAfter("://", url)
        val authority = afterScheme.substringBefore('/').substringBefore('?').substringAfterLast('@')
        return authority.ifBlank { url }.lowercase()
    }

    // --- learned state ---------------------------------------------------------------------------

    /**
     * The most URL-keyed lessons any one of the sets below will hold.
     *
     * Host-keyed sets are naturally bounded — a user has a handful of panels — but a URL-keyed one grows
     * with every channel ever tuned, and nothing here ever evicted. A long zapping session on a big
     * playlist is the case that matters. 512 is far beyond any real session: reaching it means learning
     * a format lesson about five hundred DIFFERENT streams without restarting the app, at which point
     * the oldest are of no further interest anyway.
     */
    private const val MAX_URL_LESSONS = 512

    /**
     * A URL-keyed lesson set that forgets its oldest entries rather than growing without limit.
     *
     * Insertion-ordered, so eviction drops the stream longest ago written off. A lesson recorded during
     * the tune currently on screen is therefore the newest entry in the set and cannot be evicted unless
     * five hundred further streams are written off before the channel is consulted again — which cannot
     * happen inside one tune.
     */
    private fun urlLessonSet(): MutableSet<String> = java.util.Collections.synchronizedSet(
        java.util.Collections.newSetFromMap(
            object : LinkedHashMap<String, Boolean>(64, 0.75f) {
                override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Boolean>) =
                    size > MAX_URL_LESSONS
            },
        ),
    )

    private val hlsRedirectHosts = ConcurrentHashMap.newKeySet<String>()
    private val hlsRedirectStreams = urlLessonSet()
    private val mixedHlsHosts = ConcurrentHashMap.newKeySet<String>()
    private val dashRedirectHosts = ConcurrentHashMap.newKeySet<String>()
    private val segmentRefusingHosts = ConcurrentHashMap.newKeySet<String>()
    private val singleSessionHosts = ConcurrentHashMap.newKeySet<String>()
    private val brokenTimestampStreams = urlLessonSet()
    private val noHlsVariantStreams = urlLessonSet()
    private val noHlsVariantMpvStreams = urlLessonSet()
    private val tolerantDemuxStreams = urlLessonSet()
    private val prerollDefeatedStreams = urlLessonSet()
    private val softwareArchiveHosts = ConcurrentHashMap.newKeySet<String>()
    private val uaBlockingHosts = ConcurrentHashMap.newKeySet<String>()
    private val untrustedCertificateHosts = ConcurrentHashMap.newKeySet<String>()
    private val providerMessages = ConcurrentHashMap<String, Pair<Int, String>>()

    // --- kept across app starts ---------------------------------------------------------------------

    /** When each panel-wide lesson held now was first learned (wall clock), for its expiry. */
    private val learnedAt = ConcurrentHashMap<ProviderLessons.Lesson, Long>()

    private fun hostSet(kind: ProviderLessons.Kind): MutableSet<String> = when (kind) {
        ProviderLessons.Kind.HLS_REDIRECT -> hlsRedirectHosts
        ProviderLessons.Kind.DASH_REDIRECT -> dashRedirectHosts
        ProviderLessons.Kind.REFUSES_SEGMENTS -> segmentRefusingHosts
        ProviderLessons.Kind.SINGLE_SESSION -> singleSessionHosts
        ProviderLessons.Kind.BLOCKS_DEFAULT_UA -> uaBlockingHosts
        ProviderLessons.Kind.UNTRUSTED_CERTIFICATE -> untrustedCertificateHosts
    }

    internal var clock: () -> Long = System::currentTimeMillis

    /** Completes once the stored lessons are in; already complete when nothing is stored (tests). */
    @Volatile private var loaded = CompletableDeferred(Unit)

    /** Writes the current lessons to storage; null when nothing is kept (tests, before start-up). */
    @Volatile private var saveLessons: (() -> Unit)? = null

    /**
     * Load the lessons kept by earlier runs, and keep every later change. Called once per process, at
     * start-up, before anything can tune: [awaitPersisted] holds a tune until the load is done.
     *
     * A lesson learned meanwhile is kept, never overwritten by the load; a write waits for the load, so
     * it cannot replace the stored lessons with this run's alone.
     */
    fun startPersisting(scope: CoroutineScope, read: suspend () -> String, write: suspend (String) -> Unit) {
        val done = CompletableDeferred<Unit>()
        loaded = done
        val writing = Mutex()
        saveLessons = {
            scope.launch {
                done.await()
                // The snapshot is taken under the lock, so the last write always carries the newest set.
                writing.withLock { runCatching { write(ProviderLessons.encode(learnedAt.toMap())) } }
            }
        }
        scope.launch {
            try {
                val stored = runCatching { read() }.getOrDefault("")
                val kept = ProviderLessons.decode(stored, clock())
                kept.forEach { (lesson, at) ->
                    if (learnedAt.putIfAbsent(lesson, at) == null) hostSet(lesson.kind) += lesson.host
                }
                if (kept.isNotEmpty()) {
                    android.util.Log.i("LiveEngine", "provider lessons kept from earlier runs: ${kept.keys.joinToString { "${it.kind.name.lowercase()} ${it.host}" }}")
                }
            } finally {
                done.complete(Unit)
            }
        }
    }

    /** Wait until the lessons kept by earlier runs are loaded (see [startPersisting]). */
    suspend fun awaitPersisted() = loaded.await()

    private fun learn(kind: ProviderLessons.Kind, url: String) {
        val host = hostKey(url)
        if (!hostSet(kind).add(host)) return
        learnedAt[ProviderLessons.Lesson(kind, host)] = clock()
        saveLessons?.invoke()
    }

    private fun forget(kind: ProviderLessons.Kind, host: String) {
        hostSet(kind) -= host
        if (learnedAt.remove(ProviderLessons.Lesson(kind, host)) != null) saveLessons?.invoke()
    }

    /**
     * Record that [url] — and, unless its panel is known to be mixed, every channel on its host — serves
     * HLS even though the advertised URL says `.ts`.
     *
     * Two tiers. The channel itself is always remembered, so on a mixed panel the channels that do
     * redirect still open as HLS first time instead of each paying a failed TS open again. The host is
     * remembered only while nothing has proved the panel mixed.
     */
    fun rememberHlsRedirect(url: String) {
        hlsRedirectStreams += url
        if (hostKey(url) !in mixedHlsHosts) learn(ProviderLessons.Kind.HLS_REDIRECT, url)
    }

    /** Whether [url] should open as HLS on what was learned: its own redirect, or its panel's. */
    fun isKnownHls(url: String): Boolean = url in hlsRedirectStreams || hostKey(url) in hlsRedirectHosts

    /**
     * [url] was proved to be plain TS — it played as TS after the learned HLS route failed — so its
     * panel serves plain TS on some channels and redirects others to a manifest, and the host-wide lesson
     * is wrong there: drop it and never learn it again this session. Without this one redirecting
     * channel sent every plain one through a failed HLS open and a failed `.m3u8` retry before mpv played
     * it. The redirecting channels keep their own lesson. The kept copy goes too.
     */
    fun forgetHlsRedirect(url: String) {
        val key = hostKey(url)
        mixedHlsHosts += key
        forget(ProviderLessons.Kind.HLS_REDIRECT, key)
        hlsRedirectStreams -= url
    }

    /**
     * Whether a first frame proves the panel mixed: only when this load deliberately ignored the learned
     * HLS route and played on the progressive (plain TS) route. A retry that never shows a picture — a
     * dead channel, an HTML error page — proves nothing about the panel and must not mark it.
     */
    fun firstFrameProvesMixed(lessonIgnored: Boolean, progressiveRoute: Boolean): Boolean =
        lessonIgnored && progressiveRoute

    /**
     * Whether a failed HLS open (one chosen because of a learned lesson) suggests *this* channel is plain
     * TS, so it is worth reopening as TS. Only a response that arrived and would not parse says that. An
     * HTTP status says nothing about the format: an offline channel on a redirecting panel 404s on its
     * manifest whatever it is asked for, and taking that as "plain TS" put the panel on the mixed list for
     * the rest of the session — after which mpv opened every redirected `.ts` with `reconnect_at_eof` and
     * re-read the same playlist until its open timed out, on every channel. Even then the panel is marked
     * mixed only once the TS reopen shows a picture ([firstFrameProvesMixed]).
     */
    fun disprovesHlsLesson(isFormatFailure: Boolean, httpStatus: Int?): Boolean =
        isFormatFailure && httpStatus == null

    /**
     * The offset in FFmpeg's `reconnect_at_eof` line, or null for any other line. Both wordings FFmpeg
     * has used: "Will reconnect at 222 in 0 second(s), error=End of file." and "Will retry at …".
     *
     * A live `.ts` that the panel redirects to a manifest is a short, finite response. Opened as raw TS,
     * `reconnect_at_eof` re-reads the same few hundred bytes, and FFmpeg resets its retry count on every
     * read, so nothing ends the loop but the 10 s open timeout. Only ExoPlayer used to learn such a panel,
     * so on mpv alone every channel there failed. Offsets of 0 and above [MAX_EOF_PROBE_OFFSET] are
     * ignored: nothing was read, or a feed that delivered that much was a stream that dropped.
     */
    fun eofReconnectOffset(line: String): Long? {
        val offset = EOF_RECONNECT_RX.find(line)?.groupValues?.get(1)?.toLongOrNull() ?: return null
        return offset.takeIf { it in 1..MAX_EOF_PROBE_OFFSET }
    }

    private const val MAX_EOF_PROBE_OFFSET = 64L * 1024
    private val EOF_RECONNECT_RX =
        Regex("""Will (?:reconnect|retry) at (\d+) in .*End of file""", RegexOption.IGNORE_CASE)

    /** What the first bytes of a live response are, read once to decide what an early EOF meant. */
    enum class ResponseStart { HLS_PLAYLIST, MPEG_TS, OTHER }

    /**
     * Classify the first bytes of a response. A playlist only when the body itself starts with `#EXTM3U`
     * (after an optional byte-order mark and whitespace) — a content type or a URL that says "mpegurl"
     * is not enough, panels label HTML error pages that way. `0x47` is the MPEG-TS sync byte.
     */
    fun classifyResponseStart(bytes: ByteArray): ResponseStart {
        var i = 0
        if (bytes.size >= 3 && bytes[0] == 0xEF.toByte() && bytes[1] == 0xBB.toByte() && bytes[2] == 0xBF.toByte()) i = 3
        if (i == 0 && bytes.isNotEmpty() && bytes[0] == 0x47.toByte()) return ResponseStart.MPEG_TS
        while (i < bytes.size && bytes[i].toInt().toChar().isWhitespace()) i++
        val tag = "#EXTM3U".toByteArray(Charsets.US_ASCII)
        if (bytes.size - i >= tag.size && tag.indices.all { bytes[i + it] == tag[it] }) return ResponseStart.HLS_PLAYLIST
        return ResponseStart.OTHER
    }

    /**
     * Whether an early-EOF line during a live open is worth checking what the response really is: only
     * while the open is still pending, only for a load that mpv opened as raw `.ts` with
     * `reconnect_at_eof` (that option is what loops), and once per channel.
     */
    fun eofCheckWanted(
        live: Boolean,
        opening: Boolean,
        loopingTsOpen: Boolean,
        alreadyChecked: Boolean,
    ): Boolean = live && opening && loopingTsOpen && !alreadyChecked

    /**
     * Record that [url]'s host serves DASH manifests from URLs that do not say `.mpd` (v43).
     *
     * The DASH twin of [rememberHlsRedirect], and it matters for the same reason: the traced proxy
     * publishes every channel as `…/live/mpd/{id}` and only redirects to `…/render.mpd` once asked, so
     * without a panel-wide lesson EVERY channel on it pays its own failed progressive attempt and
     * retry before playing.
     */
    fun rememberDashRedirect(url: String) = learn(ProviderLessons.Kind.DASH_REDIRECT, url)

    fun isKnownDashHost(url: String): Boolean = hostKey(url) in dashRedirectHosts

    /**
     * True when [url] itself asks for HLS — it ends in `.m3u8` — ignoring anything learned about its
     * panel.
     *
     * The distinction from [isHlsUrl] matters when deciding whether an HLS *discovery* is worth
     * remembering: a URL we deliberately requested as `.m3u8` proves nothing about what the panel does
     * with the `.ts` endpoint, and recording it as a redirect poisons every other channel there.
     */
    fun isExplicitHlsUrl(url: String): Boolean =
        url.substringBefore('?').endsWith(".m3u8", ignoreCase = true)

    /**
     * True when [url] should be treated as HLS regardless of its extension: either it already ends in
     * `.m3u8`, or it or its panel has been caught redirecting `.ts` to a manifest.
     */
    fun isHlsUrl(url: String): Boolean = isExplicitHlsUrl(url) || isKnownHls(url)

    /** Rewrite an Xtream-style `.ts` live URL to its `.m3u8` sibling; other URLs are returned as-is. */
    fun toHlsUrl(url: String): String {
        val query = url.substringAfter('?', "")
        val path = url.substringBefore('?')
        if (!path.endsWith(".ts", ignoreCase = true)) return url
        val rewritten = path.dropLast(3) + ".m3u8"
        return if (query.isEmpty()) rewritten else "$rewritten?$query"
    }

    /**
     * The `.ts` ⇄ `.m3u8` sibling of [url], or null when there is no extension to swap.
     *
     * The extension is tested on the PATH only, and any query/fragment is carried over untouched. An
     * M3U live URL like `…/stream-output.m3u8?mode=hls` ends in a *parameter* rather than an extension,
     * so testing the whole string skips the swap entirely; and the provider's own `mode` is usually
     * required, so dropping it yields a 400 instead of the sibling.
     *
     * Shared by both engines, so a channel gets the same alternate whichever one is asking.
     */
    fun alternateFormatUrl(url: String): String? {
        val cut = url.indexOfFirst { it == '?' || it == '#' }.takeIf { it >= 0 } ?: url.length
        val path = url.substring(0, cut)
        val suffix = url.substring(cut)
        val from = when {
            path.endsWith(".m3u8", ignoreCase = true) -> ".m3u8"
            path.endsWith(".ts", ignoreCase = true) -> ".ts"
            else -> return null
        }
        val to = if (from == ".m3u8") ".ts" else ".m3u8"
        return path.dropLast(from.length) + to + suffix
    }

    /**
     * Statuses where the provider is refusing the *request* rather than describing a broken stream.
     *
     * Guards the format swap above, which can only ever fix a *container* problem. Traced on a panel
     * that answers `429 "Channel limit has been reached"`: the ladder read that as a format failure,
     * went off to an invented `.ts` URL that 404s, retried the invented URL six times over ~45 s and
     * ended on an error screen blaming the channel — while the original URL worked the moment the
     * account's other stream closed. A different file extension cannot answer any of these.
     */
    fun isRequestRefusal(responseCode: Int): Boolean =
        responseCode == 401 || responseCode == 402 || responseCode == 403 || responseCode == 429 ||
            responseCode == 503 || responseCode == 509 || isSessionLimit(responseCode)

    /**
     * Record that this panel refuses its own signed segment URLs, so the *next* channel on it opens
     * straight on mpv instead of repeating ExoPlayer's dead spinner. Panel-wide because the signing
     * scheme is a property of the panel, not of one channel.
     */
    fun rememberSegmentRefusal(url: String) = learn(ProviderLessons.Kind.REFUSES_SEGMENTS, url)

    fun refusesSegments(url: String): Boolean = hostKey(url) in segmentRefusingHosts

    /**
     * Record that this panel allows only one session at a time (it answered [isSessionLimit]).
     *
     * On such a panel the two engines must never be connected at once: whichever one holds the session
     * keeps playing and the other is locked out until the holder's socket is really gone, which is the
     * whole "mpv works but ExoPlayer doesn't" (and the reverse) symptom. Panel-wide, because the limit is
     * on the *account*, not the channel.
     */
    fun rememberSessionLimit(url: String) = learn(ProviderLessons.Kind.SINGLE_SESSION, url)

    fun isSingleSession(url: String): Boolean = hostKey(url) in singleSessionHosts

    /**
     * Record that mpv can't trust this stream's video timestamps, so its next open starts on free-running
     * video timing (`correct-pts=no` + `video-sync=desync` + `framedrop=no`).
     *
     * Keyed by the **whole URL**, not the panel: a broken mux is a property of one feed, and its
     * healthy neighbours on the same panel must keep mpv's accurate audio-synced timing — free-running
     * timing drifts sound away from picture on a stream whose PTS were fine all along.
     */
    fun rememberBrokenTimestamps(url: String) { brokenTimestampStreams += url }

    fun hasBrokenTimestamps(url: String): Boolean = url in brokenTimestampStreams

    /**
     * Record that this channel has no `.m3u8` sibling **the given engine can play**, so "Prefer HLS"
     * must be ignored for it there.
     *
     * The playlist setting rewrites every Xtream `.ts` to `.m3u8` blindly, but a panel does not
     * necessarily remux *every* channel: the odd one answers its `.m3u8` with a 404, an empty body, or a
     * playlist whose segments never arrive — and the channel that played perfectly in TS mode turns into
     * a black screen or a spinner that never resolves. The fix is to fall back to the `.ts` the panel
     * does serve.
     *
     * **Scoped per engine, because "unplayable" is not the same verdict for both.** Traced on a 4K
     * channel whose `.m3u8` is served perfectly well and plays on mpv, while ExoPlayer's audio renderer
     * never produces a sample from it (`audio=false` with the buffer full). A single shared flag made
     * ExoPlayer's verdict push mpv onto `.ts` too, costing the one combination that actually worked. So
     * each engine only ever learns its own failures, and the fallback ladder gives the other engine the
     * HLS variant a fair try before giving up on it.
     *
     * Keyed by the **channel's own `.ts` URL**, and never widened to the panel: on the very same provider
     * all the other channels keep their HLS variant, which is the reason the user turned the setting on.
     * Session-only, so a panel that finishes remuxing is back to HLS after the next app start.
     *
     * **A panel-wide verdict used to exist here and was removed deliberately.** Three channels failing
     * their `.m3u8` wrote off the whole provider for the session, and the failures that reached this
     * function were not necessarily about format at all — an account-busy lockout (HTTP 458) walked three
     * channels onto their `.ts` rung in under two minutes and cost every remaining channel its HLS start
     * for the rest of the session. One channel's evidence now only ever condemns that channel.
     */
    fun rememberNoHlsVariant(tsUrl: String) {
        noHlsVariantStreams += tsUrl
    }

    fun lacksHlsVariant(tsUrl: String): Boolean = tsUrl in noHlsVariantStreams

    /** As [rememberNoHlsVariant], for mpv. */
    fun rememberNoHlsVariantMpv(tsUrl: String) {
        noHlsVariantMpvStreams += tsUrl
    }

    fun lacksHlsVariantMpv(tsUrl: String): Boolean = tsUrl in noHlsVariantMpvStreams

    /**
     * Record that this stream only opens with FFmpeg's error tolerance turned on.
     *
     * mpv runs FFmpeg's demuxers at their strict defaults, which is why a re-streamed feed with lost
     * packets, malformed PSI tables or jumping timestamps ends as an `END_FILE` here while VLC — whose TS
     * demuxer is its own, and forgiving — plays it. The tolerant options ([StubeboxPlayer.demuxerLavfOptionsFor])
     * close most of that gap, but they are a *retry*, never a default: dropping corrupt packets and
     * synthesising timestamps costs accuracy on a stream whose data was fine all along.
     *
     * Keyed by the **whole URL**: a broken mux belongs to one feed, and its healthy neighbours on the same
     * panel must keep the accurate path. Session-only.
     */
    fun rememberNeedsTolerantDemux(url: String) { tolerantDemuxStreams += url }

    fun needsTolerantDemux(url: String): Boolean = url in tolerantDemuxStreams

    /**
     * Record that this stream can never satisfy the "Pre-buffer" threshold, so it must open without one.
     *
     * ExoPlayer's `DefaultLoadControl` starts (and *resumes*) playback once **either** the requested
     * amount of media or the byte cap is reached. On a very high-bitrate feed — a 4K live channel is the
     * traced case — the byte cap is hit long before 10 s of media exists, so the time threshold is
     * unreachable: playback starts on the byte rule, drains a few frames, drops back under the cap, and
     * re-buffers immediately. The result is a `READY`/`BUFFERING` oscillation several times a second that
     * looks exactly like a frozen picture with a stuck spinner — and it defeats every stall watchdog,
     * because each `READY` cancels them before they can fire.
     *
     * Keyed by the **whole URL**: it is a property of one feed's bitrate, not of the panel, and the same
     * provider's HD channels satisfy the pre-roll fine. Session-only.
     */
    fun rememberPrerollDefeated(url: String) { prerollDefeatedStreams += url }

    fun defeatsPreroll(url: String): Boolean = url in prerollDefeatedStreams

    /**
     * Record that this panel's catch-up archive needs a SOFTWARE video decoder.
     *
     * Archive (timeshift) segments start mid-GOP, and some TV-class hardware decoders can't resync from
     * that: the decoder accepts the format, audio plays, and no video frame is ever emitted (Realtek OMX:
     * "setPortMode … DynamicANWBuffer failed", "BAD CODEC: stride 1920 -> 64"). A software decoder picks
     * up cleanly at the next keyframe.
     *
     * Catch-up used to be pinned to software *unconditionally* for that reason, which cost every panel
     * hardware decoding — including the majority whose decoders cope fine. So archives now open in
     * hardware and drop to software only once this panel has actually been caught failing; the cost of a
     * panel that does fail is one silent retry on the session's first catch-up.
     *
     * Panel-wide, because the mid-GOP archive mux is a property of the panel's timeshift server, not of
     * one channel. Session-only like the rest: one stalled open must not cost every later app start its
     * hardware decoder, and the stall does not reproduce on every open of the same panel.
     */
    fun rememberArchiveNeedsSoftware(url: String) { softwareArchiveHosts += hostKey(url) }

    fun archiveNeedsSoftware(url: String): Boolean = hostKey(url) in softwareArchiveHosts

    /**
     * Record that this panel refuses [de.stubebox.tv.core.network.HttpClient.DEFAULT_USER_AGENT], so every
     * later request to it — either engine, any channel — starts on the fallback identity.
     *
     * Panel-wide, because a WAF rule is configured for the site, not per stream. Kept for a week at most
     * ([ProviderLessons]): a provider that drops the rule is back to the default identity after that,
     * which matters because the default is the one most panels actually want.
     *
     * Only ever recorded when the user has NOT configured a User-Agent for the source. An explicit
     * setting is the user's decision and is never second-guessed or overwritten.
     */
    fun rememberBlocksDefaultUserAgent(url: String) = learn(ProviderLessons.Kind.BLOCKS_DEFAULT_UA, url)

    fun blocksDefaultUserAgent(url: String): Boolean = hostKey(url) in uaBlockingHosts

    /**
     * Record that ExoPlayer refused this panel's TLS certificate (self-signed, expired, or for another
     * name), so later tunes of its channels start on mpv, which plays them, instead of failing each
     * ExoPlayer rung first. Routing only: "ExoPlayer only" still keeps them on ExoPlayer.
     */
    fun rememberUntrustedCertificate(url: String) = learn(ProviderLessons.Kind.UNTRUSTED_CERTIFICATE, url)

    fun distrustsCertificate(url: String): Boolean = hostKey(url) in untrustedCertificateHosts

    /**
     * Whether [error] — anywhere in its cause chain — is the platform refusing the server's certificate,
     * rather than a TLS failure of the connection itself (a reset during the handshake says nothing about
     * the certificate, and must not move a panel's channels to the other engine for a week).
     */
    fun isUntrustedCertificate(error: Throwable): Boolean = generateSequence(error) { it.cause }.take(16).any {
        it is java.security.cert.CertificateException ||
            it is java.security.cert.CertPathValidatorException ||
            it is javax.net.ssl.SSLPeerUnverifiedException
    }

    /**
     * Keep the panel's own explanation of a refusal, so an error screen can quote it verbatim.
     *
     * "Channel limit has been reached. Stop one of your active streams before opening a new channel."
     * says in one line what a status code can only hint at, and it is the difference between the user
     * closing the TV in the other room and the user assuming the channel is dead. Only ExoPlayer can
     * capture it — mpv/FFmpeg never exposes a response body, it just reports "HTTP error 429" — so it
     * is kept panel-wide here and mpv's error screen reads it back.
     *
     * Stored with the status it explained: a stale "channel limit" line quoted under a later 404 would
     * be worse than no message at all.
     */
    fun rememberProviderMessage(url: String, responseCode: Int, message: String) {
        providerMessages[hostKey(url)] = responseCode to message
    }

    /** The panel's own words for [responseCode], if it gave any this session; null otherwise. */
    fun providerMessage(url: String, responseCode: Int): String? =
        providerMessages[hostKey(url)]?.takeIf { it.first == responseCode }?.second

    /** Test hook — clears everything. */
    internal fun clearForTest() {
        hlsRedirectHosts.clear(); hlsRedirectStreams.clear(); mixedHlsHosts.clear(); segmentRefusingHosts.clear(); singleSessionHosts.clear()
        dashRedirectHosts.clear()
        brokenTimestampStreams.clear(); softwareArchiveHosts.clear()
        noHlsVariantStreams.clear(); noHlsVariantMpvStreams.clear(); prerollDefeatedStreams.clear()
        tolerantDemuxStreams.clear()
        uaBlockingHosts.clear(); providerMessages.clear()
        untrustedCertificateHosts.clear(); learnedAt.clear()
        saveLessons = null
        loaded = CompletableDeferred(Unit)
        clock = System::currentTimeMillis
    }
}
